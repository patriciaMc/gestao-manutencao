# SIGM com interface no padrão do Victor — versão de trabalho

Esta entrega combina a direção visual do projeto de Victor Moy (cabeçalho escuro, navegação lateral clara, filtros, cartões e listas compactas) com as regras operacionais do SIGM: patrimônio, dashboard, triagem Civil e Equipamentos, consultas por unidade e controle de SLA.

**A pasta public abre uma versão demonstrativa funcional.** Há também um adaptador e scripts SQL para uma base Supabase do SIGM em homologação. Nenhuma base real foi conectada ou modificada nesta entrega.

## 1. Abrir a versão

Na pasta desta entrega:

```bash
python3 -m http.server 8082 --bind 127.0.0.1 --directory public
```

Abra http://127.0.0.1:8082. Não abra index.html por duplo clique: os módulos JavaScript e a persistência local precisam do servidor.

- Painel: http://127.0.0.1:8082/index.html#dashboard
- Triagem com unidade de exemplo selecionada: http://127.0.0.1:8082/index.html?cenario=triagem#civil/novo
- Equipamentos: http://127.0.0.1:8082/index.html#equipamentos
- Patrimônio: http://127.0.0.1:8082/index.html#patrimonio

A demonstração começa com 12 chamados fictícios e 64 patrimônios fictícios. Os nomes das unidades são exemplos; os números, valores e contagens não representam a base real. Os cadastros feitos na demonstração ficam no IndexedDB desse navegador e continuam após recarregar. Não há login de produção em modo demo. Trocar o navegador ou limpar os dados do site cria outra demonstração.

## 2. O que a versão faz

- Mantém cadastro e painel de patrimônio, com filtros por unidade, categoria, família e busca de item/tombamento.
- Apresenta indicadores e distribuições de chamados por unidade e categoria.
- Permite abrir chamados Civil e de Equipamentos, sem digitar GLPI.
- Gera referências como CIV-2026-000010 e EQP-2026-000004. O número só é confirmado após salvar. Não é calculado pela quantidade de linhas da página.
- Consulta os chamados da unidade durante a abertura e mostra até oito registros, contagem total, abertos e abertos na mesma categoria. É uma amostra; o botão de consulta/filtros permite ver o restante.
- Destaca e ordena vazamento contínuo, hidráulica, telhado/cobertura, elétrica e ar-condicionado, nessa ordem. Chamados encerrados ficam depois dos abertos. Dentro do grupo vêm SLA vencido e antiguidade.
- O destaque não decide sozinho urgência contratual: prioridade continua sendo Baixa, Média ou Muito Alta, escolhida pelo operador.
- Registra observação na alteração de status, incluindo questionamentos e agendamento de visita.
- Mantém consultas a referências GLPI antigas quando o campo existe. As novas aberturas não dependem de GLPI e não acessam esse serviço externo.

## 3. Controle de SLA

- Solicitação de avaliação: o SLA ainda não iniciou.
- Primeiro encaminhamento ao prestador: inicia o prazo.
- Mudança para EM ROTA/EM EXECUÇÃO: preserva o início e o vencimento originais.
- Baixa: planejado, sem vencimento automático.
- Chamado encerrado: não aparece como SLA vencido ativo.
- Prazo ausente em um chamado já iniciado: “Prazo não configurado”, sem tratar o registro como se estivesse em dia.

Na demonstração, Média usa 48 h e Muito Alta 2 h, como exemplos do SIGM anterior. **Na base real Civil, o prazo vem da configuração contratual do prestador.** Equipamentos tem política separada na tabela sigm_v4_politicas_sla e deve ser revisada antes de permitir liberação: os valores iniciais 48/2 não são assumidos como regra contratual validada. O SQL exige revisada=true em Equipamentos para liberar um chamado.

Não foi criada nova regra de pausa de prazo. Pagamento continua no módulo financeiro/medição original, com suas validações; o detalhe desta versão não muda um chamado para PAGO. Não altera contratos, notas fiscais ou medições.

## 4. Origem dos arquivos e limitação do ZIP indicado

O arquivo /home/patriciamcarboni/SIGM3.0.zip indicado na solicitação não passou na validação de ZIP e não contém as assinaturas de um arquivo ZIP. Não foi renomeado nem modificado.

Foi usada como referência a cópia local válida:

`/home/patriciamcarboni/sigm backup/SIGM3.0.zip`

Ela foi modificada em 20/10/2026 e contém a estrutura de frontend HTML/JS e scripts Supabase do SIGM. Uma seleção dos arquivos de regras fica em referencia-sigm/ para o programador comparar. Configurações, credenciais, arquivos de sessão e caches não fazem parte da entrega. Esse backup pode não conter mudanças posteriores presentes no arquivo inválido; uma cópia nova válida será necessária para conferi-las.

## 5. Como pegar os arquivos do projeto do Victor

```bash
git clone https://github.com/victor-moy/gestao-patrimonio.git
cd gestao-patrimonio
```

Para o dashboard de patrimônio nativo React/Express, a entrega inclui integracao-victor/inventario-inteligente.patch, preparado na tarefa anterior sobre o commit eb6ef205c4702f61dd6984c7a9f47dc58407923f. Conferir com git apply --check antes de aplicar.

**As tecnologias das duas bases são diferentes:** o projeto do Victor usa React/Express/Prisma/PostgreSQL; o SIGM do backup usa frontend HTML/JS e Supabase. Esta nova versão usa a estrutura de acesso do SIGM e a direção visual do Victor; não é um fork React pronto para substituir a aplicação dele. Não executar os scripts SQL desta pasta no banco Prisma do Victor. O programador deve escolher a base final e adaptar o contrato de dados, preservando autorização e as regras de SLA. O modelo de ordenação e a interface desta entrega servem como referência funcional para esse porte.

## 6. Arquivos

- public/index.html e public/style.css: interface responsiva.
- public/js/app.mjs: dashboard, patrimônio, triagem, consulta e detalhes.
- public/js/model.mjs: classificação, filtros, contagens, ordenação e SLA.
- public/js/store.mjs: persistência demo e adaptador Supabase.
- public/js/demo.mjs: dados fictícios.
- public/config.example.js: configuração de exemplo sem credenciais.
- sql/13_SIGM_VICTOR_NUMERACAO_E_TRIAGEM.sql: numeração, RPCs de triagem/status, idempotência e políticas de SLA.
- sql/14_SIGM_VICTOR_PATRIMONIO.sql: complemento do cadastro patrimonial existente.
- imagens/: painel, patrimônio, Civil com amostragem, Equipamentos e mobile.
- tests/: testes automatizados e verificação da interface.
- INTEGRACAO-SUPABASE.md: preparação e validações para a base de homologação.

## 7. Validação realizada

- Oito testes unitários do modelo de classificação, busca e SLA: aprovados.
- Teste no navegador: painel, abertura sem GLPI, amostragem da unidade/categoria, número próprio, início do SLA na liberação, prazo preservado em EM ROTA, reenvio idempotente e numeração concorrente na demonstração: aprovado.
- Capturas desktop 1680×1150 e mobile 390×1700 conferidas.
- A camada SQL não foi executada em um Supabase/PostgreSQL real. Seus objetos, constraints e políticas devem ser homologados na estrutura real antes de publicar. O teste de concorrência realizado foi no IndexedDB da demonstração, não no PostgreSQL.
- Não houve deploy, push no GitHub, importação da planilha real nem alteração do Apps Script da prefeitura.
