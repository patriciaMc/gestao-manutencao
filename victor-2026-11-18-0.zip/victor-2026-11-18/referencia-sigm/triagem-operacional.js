// Triagem Civil — interface original, campos e persistência próprios.
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statuses=['SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)'];
const opts=(arr,ph)=>`<option value="">${e(ph)}</option>${arr.map(x=>`<option value="${e(x.value??x)}">${e(x.label??x)}</option>`).join('')}`;
export async function abrirTriagemCivil({db,root}){
 root.innerHTML=`<div class="breadcrumb">SIGM-SES › <strong>OPERAÇÃO</strong> › Triagem Civil</div><div class="page-title"><div><h2>Triagem Civil</h2><p>Classificação técnica, SLA e envio aos prestadores</p></div></div><div class="split-screen"><section class="panel"><div class="panel-header"><h3>Dados do chamado</h3></div><form id="tc-form"><div class="form-grid">
 <div class="field"><label>ID GLPI</label><input id="tc-glpi" inputmode="numeric" required placeholder="Ex.: 2610150001"></div>
 <div class="field"><label>Prestador (opcional se solicitar avaliação)</label><select id="tc-prestador">${opts([],'Selecione o prestador')}</select></div>
 <div class="field"><label>Unidade</label><select id="tc-unidade" required>${opts([],'Selecione a unidade')}</select></div>
 <div class="field"><label>Setor</label><select id="tc-setor">${opts([],'Selecione o setor')}</select></div>
 <div class="field"><label>Categoria</label><select id="tc-categoria" required>${opts([],'Selecione a categoria')}</select><small id="tc-significado" style="display:block;margin-top:5px"></small></div>
 <div class="field"><label>Data de abertura</label><input type="date" id="tc-data" required></div>
 <div class="field wide"><label>Descrição do chamado (obrigatória)</label><textarea id="tc-descricao" rows="4" required maxlength="20000" placeholder="Transcreva ou resuma a descrição original do GLPI, local e serviço solicitado..."></textarea><small class="muted">Preenchimento obrigatório para que o avaliador receba a demanda completa. A descrição não é buscada automaticamente no GLPI.</small></div>
 <div class="field wide tc-foto-campo"><label class="tc-photo-label" for="tc-tem-foto"><input id="tc-tem-foto" name="tem_foto_glpi" type="checkbox" value="sim"><span><strong>Há foto anexada ao chamado no GLPI?</strong><small class="muted" style="display:block;margin-top:3px">Marque esta caixa se houver foto no chamado original. O SIGM-SES registra apenas a informação; a foto continua no GLPI.</small></span></label></div>
 </div><div class="divider"></div><h3 class="section-title">Classificação e encaminhamento</h3><div class="form-grid">
 <div class="field"><label>Prioridade</label><select id="tc-prioridade" required>${opts(['Baixa','Média','Muito Alta'],'Selecione')}</select></div>
 <div class="field"><label>SLA (estimado)</label><input id="tc-sla" readonly placeholder="Conforme contrato"></div>
 <div class="field"><label>Status triagem</label><select id="tc-status-triagem">${opts(statuses,'Selecione')}</select></div>
 </div><div class="form-footer"><button class="btn" type="button" id="tc-preview">Prévia da classificação</button><button class="btn primary" type="submit" id="tc-salvar">Salvar triagem</button></div><div id="tc-msg" role="status" class="small"></div></form></section>
 <section class="panel"><div class="panel-header"><h3>Histórico de chamados semelhantes</h3><p class="muted small">Somente pendentes de execução, sem número nem valor de medição</p></div><div id="tc-historico" class="history-box">Selecione unidade e categoria para pesquisar chamados cadastrados no Supabase.</div><div class="divider"></div><div class="panel-header"><h3>Fontes utilizadas</h3></div><p class="muted small">Fotos são consultadas no chamado original do GLPI. O SIGM registra apenas se existe foto anexada.</p><p class="muted small">CHAMADOS MALBEC, CHAMADOS ARACAJU e GLPI DADOS: a busca direta nas planilhas requer a API protegida de integração. Os resultados abaixo vêm do Supabase.</p></section></div>
 <dialog id="tc-confirmacao-foto" class="tc-confirmacao-foto" aria-labelledby="tc-confirmacao-foto-titulo" aria-describedby="tc-confirmacao-foto-texto">
  <form method="dialog">
   <h3 id="tc-confirmacao-foto-titulo">Antes de salvar: há foto no GLPI?</h3>
   <p id="tc-confirmacao-foto-texto">Confira o chamado original e escolha uma resposta. Essa informação ficará disponível na Avaliação Técnica e nos demais módulos da Civil.</p>
   <div class="tc-confirmacao-foto-botoes">
    <button class="btn" type="submit" value="cancelar">Voltar sem salvar</button>
    <button class="btn" type="submit" value="nao">Não tem foto</button>
    <button class="btn primary" type="submit" value="sim">Sim, tem foto</button>
   </div>
  </form>
 </dialog>`;
 const $=id=>root.querySelector('#'+id),msg=(s)=>{$('tc-msg').textContent=s};
 $('tc-data').value=[new Date().getFullYear(),String(new Date().getMonth()+1).padStart(2,'0'),String(new Date().getDate()).padStart(2,'0')].join('-');
 if(!db){msg('Sessão Supabase indisponível. O salvamento está desativado.');$('tc-salvar').disabled=true;return;}
 const [pr,un,st,ca]=await Promise.all([db.from('prestadores').select('id,nome,servico').order('nome'),db.from('sigm_unidades_cadastro').select('*').limit(1000),db.from('sigm_setores_cadastro').select('*').limit(1000),db.from('sigm_categorias_civil').select('id,nome,significado,ativo').limit(1000)]);
 if(pr.error)msg('Erro ao consultar prestadores: '+pr.error.message);
 const prestadores=pr.data||[];$('tc-prestador').innerHTML=opts(prestadores.map(x=>({value:x.id,label:x.nome})),'A definir pela Avaliação Técnica');
 const unidades=un.data||[];$('tc-unidade').innerHTML=opts(unidades.map(x=>({value:x.id,label:x.nome||x.unidade||x.descricao||x.id})),'Selecione a unidade');
 const setores=st.data||[];const catalogo=ca.data||[];if(ca.error)msg('Não foi possível consultar o catálogo de categorias: '+ca.error.message);
 function setoresDaUnidade(){const id=$('tc-unidade').value;const list=setores.filter(x=>!x.unidade_id||String(x.unidade_id)===id);$('tc-setor').innerHTML=opts(list.map(x=>({value:x.id,label:x.nome||x.setor||x.descricao||x.id})),'Selecione o setor');}
 $('tc-unidade').onchange=()=>{setoresDaUnidade();historico()};setoresDaUnidade();
 let cfg=null;
 function categoriasLivres(manter){
   const anterior=manter??$('tc-categoria').value;
   $('tc-categoria').innerHTML=opts(catalogo.filter(x=>x.ativo!==false).map(x=>({value:x.nome,label:x.nome})),'Selecione a categoria');
   if([...$('tc-categoria').options].some(x=>x.value===anterior))$('tc-categoria').value=anterior;
   $('tc-significado').textContent='Categoria preliminar; a Avaliação Técnica definirá o prestador.';
   atualizarSla();
 }
 async function carregarContrato(){
   const anterior=$('tc-categoria').value;
   cfg=null;const id=$('tc-prestador').value;
   if(!id){$('tc-status-triagem').value='SOLICITO AVALIAÇÃO TÉCNICA';$('tc-prestador').required=false;categoriasLivres(anterior);historico();return;}
   $('tc-categoria').innerHTML=opts([],'Carregando contrato...');$('tc-significado').textContent='';
   const r=await db.from('sigm_config_contratos_civil').select('*').eq('prestador_id',id).maybeSingle();
   if(r.error){msg('Erro na configuração do prestador: '+r.error.message);return;}
   cfg=r.data;
   if(!cfg){
     if($('tc-status-triagem').value==='SOLICITO AVALIAÇÃO TÉCNICA'){categoriasLivres(anterior);return;}
     msg('Configure o contrato do prestador antes de encaminhar.');return;
   }
   const permitidas=(Array.isArray(cfg.categorias)?cfg.categorias:[]).filter(n=>catalogo.some(c=>c.nome===n&&c.ativo!==false));
   $('tc-categoria').innerHTML=opts(permitidas,'Selecione a categoria');
   if(permitidas.includes(anterior))$('tc-categoria').value=anterior;
   else if(anterior){msg('A categoria anterior não consta no contrato deste prestador. Selecione outra ou solicite avaliação técnica.');}
   atualizarSla();historico();
 }
 $('tc-prestador').onchange=carregarContrato;
 $('tc-status-triagem').onchange=()=>{
   if(!$('tc-prestador').value){$('tc-status-triagem').value='SOLICITO AVALIAÇÃO TÉCNICA';$('tc-prestador').required=false;msg('Sem prestador definido: o chamado seguirá automaticamente à Avaliação Técnica.');}
   else $('tc-prestador').required=$('tc-status-triagem').value==='LIBERADO PARA ATENDIMENTO (PLANEJADO)';
   carregarContrato();
 };
 categoriasLivres();$('tc-status-triagem').value='SOLICITO AVALIAÇÃO TÉCNICA';
 const mod=await import('./contrato-modal-prestador.js');
 // Descrições exibidas com base no catálogo da configuração contratual, sem duplicar sua lista.
 const descricaoCategoria=typeof mod.descricaoCategoriaCivil==='function'?mod.descricaoCategoriaCivil:()=>'';
 $('tc-categoria').onchange=()=>{$('tc-significado').textContent=descricaoCategoria($('tc-categoria').value);historico()};
 function atualizarSla(){const p=$('tc-prioridade').value;$('tc-sla').value=!cfg?'Somente após encaminhamento':p==='Baixa'?(cfg.sla_baixa_texto||'Conforme programação do coordenador'):p==='Média'?`${cfg.sla_media_horas} horas`:p==='Muito Alta'?`${cfg.sla_muito_alta_horas} horas`:'';}
 $('tc-prioridade').onchange=atualizarSla;
 // Status GLPI é derivado exclusivamente do status de triagem; não há seletor GLPI na tela.

 $('tc-preview').onclick=()=>msg(`Prestador: ${$('tc-prestador').selectedOptions[0]?.textContent||'—'} | Categoria: ${$('tc-categoria').value||'—'} | Prioridade: ${$('tc-prioridade').value||'—'} | SLA: ${$('tc-sla').value||'—'}`);
 async function historico(){const unidade=$('tc-unidade').value,categoria=$('tc-categoria').value;const box=$('tc-historico');if(!unidade||!categoria){box.textContent='Selecione unidade e categoria para pesquisar.';return;}const cat=catalogo.find(x=>x.nome===categoria);if(!cat){box.textContent='Categoria não cadastrada no catálogo da Civil.';return;}box.textContent='Pesquisando chamados...';
 const r=await db.from('sigm_civil_chamados').select('id_glpi,descricao,status_sigm,prioridade,tem_foto_glpi').eq('unidade_id',Number(unidade)).eq('categoria_id',cat.id).eq('medicao_registrada',false).not('status_sigm','in','("PAGO","ENCERRADO")').order('criado_em',{ascending:false}).limit(30);
 if(r.error){box.textContent='Pesquisa indisponível: '+r.error.message;return;}
 const rows=r.data||[];box.innerHTML=rows.length?`<div style="width:100%;text-align:left">${rows.map(x=>`<div style="padding:9px;border-bottom:1px solid #ddd"><strong><a target="_blank" rel="noopener noreferrer" href="https://svctmp.joinville.sc.gov.br/front/ticket.form.php?id=${encodeURIComponent(x.id_glpi)}">GLPI ${e(x.id_glpi)}</a></strong> — ${e(x.status_sigm)}${x.tem_foto_glpi?'<div class="small" style="color:#08769b">📷 Foto no GLPI</div>':''}<div class="small muted">${e(x.descricao).slice(0,220)}</div></div>`).join('')}</div>`:'Nenhum chamado pendente sem medição encontrado no Supabase. A busca direta nas planilhas ainda depende da integração.';}
 // Exige resposta explícita toda vez que a Triagem Civil é salva. Não usa alert/confirm nativos.
 function perguntarSeTemFoto(){
   const janela=$('tc-confirmacao-foto');
   janela.returnValue='';
   return new Promise(resolve=>{
     janela.addEventListener('close',()=>resolve(janela.returnValue),{once:true});
     janela.showModal();
   });
 }
 $('tc-form').onsubmit=async ev=>{ev.preventDefault();const status=$('tc-status-triagem').value; if(status===statuses[1]&&!cfg){msg('Selecione um prestador com contrato para preparar o encaminhamento.');return;}if(!$('tc-categoria').value||!$('tc-prioridade').value){msg('Informe categoria e prioridade.');return;}
 if(!statuses.includes(status)){msg('Selecione o status da Triagem.');return;}const glpi=status==='SOLICITO AVALIAÇÃO TÉCNICA'?'Novo':'Em atendimento (planejado)';
 const cat=catalogo.find(x=>x.nome===$('tc-categoria').value&&x.ativo!==false);if(!cat){msg('Categoria não cadastrada no catálogo da Civil. Execute o SQL de sincronização.');return;}
 const glpiId=$('tc-glpi').value.trim();
 const horas=!cfg?null:($('tc-prioridade').value==='Média'?Number(cfg.sla_media_horas):$('tc-prioridade').value==='Muito Alta'?Number(cfg.sla_muito_alta_horas):null);
 if(horas!==null&&(!Number.isFinite(horas)||horas<=0)){msg('O contrato não possui prazo válido para esta prioridade.');return;}
 const descricao=$('tc-descricao').value.trim();
 if (!descricao || descricao.toLowerCase()==='sem descrição informada') {msg('Informe a descrição real do chamado antes de salvar. Consulte o GLPI, se necessário.');$('tc-descricao').focus();return;}
 // A caixa visível é apenas informativa: a resposta final é pedida em cada salvamento.
 $('tc-salvar').disabled=true;
 let respostaFoto;
 try { respostaFoto=await perguntarSeTemFoto(); }
 catch(err){$('tc-salvar').disabled=false;msg('Não foi possível abrir a confirmação de fotos. Tente novamente.');return;}
 if(!['sim','nao'].includes(respostaFoto)){
   $('tc-salvar').disabled=false;
   msg('Salvamento cancelado. Nenhuma informação foi gravada.');
   return;
 }
 $('tc-tem-foto').checked=respostaFoto==='sim';
 const payload={tem_foto_glpi:respostaFoto==='sim',id_glpi:glpiId,prestador_id:$('tc-prestador').value||null,unidade_id:Number($('tc-unidade').value),setor_id:$('tc-setor').value?Number($('tc-setor').value):null,categoria_id:cat.id,data_abertura:$('tc-data').value,descricao,prioridade:$('tc-prioridade').value,sla_texto:$('tc-sla').value,sla_horas:horas,status_triagem:status};
 $('tc-salvar').disabled=true;
 const r=await db.rpc('sigm_civil_salvar_triagem',{p_dados:payload});
 $('tc-salvar').disabled=false;
 if(r.error){msg('Erro ao salvar: '+r.error.message);return;}
 msg('Triagem salva. '+(status===statuses[0]?'Aguardando avaliação técnica, sem iniciar SLA.':'Aguardando comunicação no GLPI, sem iniciar SLA.') );
 $('tc-form').reset(); $('tc-data').value=[new Date().getFullYear(),String(new Date().getMonth()+1).padStart(2,'0'),String(new Date().getDate()).padStart(2,'0')].join('-');
 cfg=null;categoriasLivres();$('tc-status-triagem').value='SOLICITO AVALIAÇÃO TÉCNICA';$('tc-prestador').required=false; $('tc-setor').innerHTML=opts([],'Selecione a unidade'); $('tc-significado').textContent=''; $('tc-sla').value=''; historico();};
}
