-- Execute após 01_SIGM_CIVIL_E_EQUIPAMENTOS.sql; preserva registros existentes.
-- SLA começa somente no PRIMEIRO encaminhamento ao prestador.
BEGIN;
ALTER TABLE public.sigm_civil_chamados ALTER COLUMN inicio_sla DROP NOT NULL;
ALTER TABLE public.sigm_civil_chamados ALTER COLUMN inicio_sla DROP DEFAULT;
-- Registros antigos com avaliação técnica podem ter SLA iniciado indevidamente.
-- NÃO apagamos horários antigos automaticamente: revise-os individualmente se necessário.
CREATE OR REPLACE FUNCTION public.sigm_civil_salvar_triagem(p_dados jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_id uuid; v_existente public.sigm_civil_chamados%ROWTYPE;
 v_cfg public.sigm_config_contratos_civil%ROWTYPE; v_cat text; v_prazo numeric;
 v_prior text; v_status text; v_dest text; v_inicio timestamptz; v_inicio_efetivo timestamptz;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado à Triagem Civil'; END IF;
 v_prior := p_dados->>'prioridade'; v_status := p_dados->>'status_triagem';
 IF v_prior NOT IN ('Baixa','Média','Muito Alta') OR v_status NOT IN ('SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)') THEN RAISE EXCEPTION 'Prioridade ou status inválido'; END IF;
 IF nullif(btrim(p_dados->>'id_glpi'),'') IS NULL OR nullif(btrim(p_dados->>'descricao'),'') IS NULL THEN RAISE EXCEPTION 'GLPI e descrição são obrigatórios'; END IF;
 SELECT * INTO v_cfg FROM public.sigm_config_contratos_civil WHERE prestador_id=(p_dados->>'prestador_id')::uuid;
 IF NOT FOUND THEN RAISE EXCEPTION 'Prestador sem configuração contratual'; END IF;
 SELECT nome INTO v_cat FROM public.sigm_categorias_civil WHERE id=(p_dados->>'categoria_id')::bigint AND ativo IS TRUE;
 IF v_cat IS NULL OR NOT (to_jsonb(v_cfg.categorias) ? v_cat) THEN RAISE EXCEPTION 'Categoria não autorizada no contrato'; END IF;
 IF v_prior='Média' THEN v_prazo:=v_cfg.sla_media_horas;
 ELSIF v_prior='Muito Alta' THEN v_prazo:=v_cfg.sla_muito_alta_horas;
 ELSE v_prazo:=NULL; END IF;
 IF v_prior<>'Baixa' AND (v_prazo IS NULL OR v_prazo<=0) THEN RAISE EXCEPTION 'Prazo SLA inválido no contrato'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.sigm_setores_cadastro s WHERE s.id=nullif(p_dados->>'setor_id','')::bigint AND s.unidade_id=(p_dados->>'unidade_id')::bigint) AND nullif(p_dados->>'setor_id','') IS NOT NULL THEN
   RAISE EXCEPTION 'Setor não pertence à unidade selecionada'; END IF;
 v_dest:=CASE WHEN v_status='SOLICITO AVALIAÇÃO TÉCNICA' THEN 'AVALIACAO' ELSE 'PRESTADOR' END;
 SELECT * INTO v_existente FROM public.sigm_civil_chamados WHERE id_glpi=p_dados->>'id_glpi' FOR UPDATE;
 IF FOUND THEN
   IF (v_existente.inicio_sla IS NOT NULL AND v_dest='AVALIACAO') OR v_existente.etapa_atual NOT IN ('AVALIACAO','PRESTADOR') OR v_existente.status_prestador IS NOT NULL OR v_existente.status_medicao IS NOT NULL THEN
     RAISE EXCEPTION 'Chamado já avançou no fluxo; use o módulo responsável'; END IF;
   UPDATE public.sigm_civil_chamados SET
    prestador_id=(p_dados->>'prestador_id')::uuid,unidade_id=(p_dados->>'unidade_id')::bigint,
    setor_id=nullif(p_dados->>'setor_id','')::bigint,categoria_id=(p_dados->>'categoria_id')::bigint,
    data_abertura=(p_dados->>'data_abertura')::date,descricao=p_dados->>'descricao',
    prioridade=v_prior,sla_texto=CASE WHEN v_prior='Baixa' THEN coalesce(v_cfg.sla_baixa_texto,'Programado') ELSE v_prazo::text||' horas' END,
    sla_horas=v_prazo,
    inicio_sla=CASE WHEN v_dest='PRESTADOR' THEN coalesce(v_existente.inicio_sla,now()) ELSE v_existente.inicio_sla END,
    vence_em=CASE WHEN v_dest='PRESTADOR' AND v_prazo IS NOT NULL THEN coalesce(v_existente.inicio_sla,now())+(v_prazo*interval '1 hour') ELSE NULL END,
    alerta_em=CASE WHEN v_dest='PRESTADOR' AND v_prazo IS NOT NULL THEN coalesce(v_existente.inicio_sla,now())+(v_prazo*interval '1 hour')+interval '30 minutes' ELSE NULL END,
    status_triagem=v_status,status_sigm=v_status,etapa_atual=v_dest,atualizado_em=now()
   WHERE id=v_existente.id RETURNING id INTO v_id;
 ELSE
   v_inicio:=CASE WHEN v_dest='PRESTADOR' THEN now() ELSE NULL END;
   INSERT INTO public.sigm_civil_chamados
    (id_glpi,prestador_id,unidade_id,setor_id,categoria_id,data_abertura,descricao,prioridade,sla_texto,sla_horas,inicio_sla,vence_em,alerta_em,status_triagem,status_sigm,etapa_atual)
   VALUES (p_dados->>'id_glpi',(p_dados->>'prestador_id')::uuid,(p_dados->>'unidade_id')::bigint,nullif(p_dados->>'setor_id','')::bigint,
    (p_dados->>'categoria_id')::bigint,(p_dados->>'data_abertura')::date,p_dados->>'descricao',v_prior,
    CASE WHEN v_prior='Baixa' THEN coalesce(v_cfg.sla_baixa_texto,'Programado') ELSE v_prazo::text||' horas' END,
    v_prazo,v_inicio,CASE WHEN v_inicio IS NULL OR v_prazo IS NULL THEN NULL ELSE v_inicio+(v_prazo*interval '1 hour') END,
    CASE WHEN v_inicio IS NULL OR v_prazo IS NULL THEN NULL ELSE v_inicio+(v_prazo*interval '1 hour')+interval '30 minutes' END,v_status,v_status,v_dest)
   RETURNING id INTO v_id;
 END IF;
 INSERT INTO public.sigm_civil_movimentacoes(chamado_id,origem,destino,status_anterior,status_novo,observacao)
 VALUES(v_id,'TRIAGEM',v_dest,v_existente.status_sigm,v_status,'Triagem salva pelo usuário autenticado');
 RETURN v_id;
END $$;


CREATE OR REPLACE FUNCTION public.sigm_civil_atualizar_status(p_dados jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v public.sigm_civil_chamados%ROWTYPE; v_status text; v_origem text; v_dest text; v_num text; v_val numeric;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
 SELECT * INTO v FROM public.sigm_civil_chamados WHERE id=(p_dados->>'chamado_id')::uuid FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Chamado não encontrado'; END IF;
 v_origem:=p_dados->>'origem'; v_status:=p_dados->>'status';v_dest:=v.etapa_atual;
 IF nullif(btrim(p_dados->>'observacao'),'') IS NULL THEN RAISE EXCEPTION 'Justificativa obrigatória'; END IF;
 IF v_origem='AVALIACAO' THEN
  IF v.etapa_atual<>'AVALIACAO' THEN RAISE EXCEPTION 'Chamado não está em avaliação'; END IF;
  IF v_status NOT IN ('LIBERADO PARA ATENDIMENTO (PLANEJADO)','UNIFICADO','DUPLICADO','EM ANÁLISE','ENCERRADO','OUTRO PRESTADOR') THEN RAISE EXCEPTION 'Status de avaliação inválido'; END IF;
  v_dest:=CASE WHEN v_status='LIBERADO PARA ATENDIMENTO (PLANEJADO)' THEN 'PRESTADOR' WHEN v_status IN ('ENCERRADO','UNIFICADO','DUPLICADO') THEN 'ENCERRADO' ELSE 'AVALIACAO' END;
  UPDATE public.sigm_civil_chamados SET status_avaliacao_tecnica=v_status,status_sigm=v_status,etapa_atual=v_dest,
    inicio_sla=CASE WHEN v_dest='PRESTADOR' THEN coalesce(inicio_sla,now()) ELSE inicio_sla END,
    vence_em=CASE WHEN v_dest='PRESTADOR' AND sla_horas IS NOT NULL THEN coalesce(inicio_sla,now())+sla_horas*interval '1 hour' ELSE vence_em END,
    alerta_em=CASE WHEN v_dest='PRESTADOR' AND sla_horas IS NOT NULL THEN coalesce(inicio_sla,now())+sla_horas*interval '1 hour'+tolerancia_minutos*interval '1 minute' ELSE alerta_em END,
    atualizado_em=now() WHERE id=v.id;
 ELSIF v_origem='PRESTADOR' THEN
  IF v.etapa_atual<>'PRESTADOR' THEN RAISE EXCEPTION 'Chamado não está com prestador'; END IF;
  IF v_status NOT IN ('EM EXECUÇÃO','CONCLUÍDO','NOTIFICADO','PENDENTE DOCUMENTAÇÃO DE ORDEM DE SERVIÇO','EM REEXECUÇÃO','REEXECUÇÃO CONCLUÍDA') THEN RAISE EXCEPTION 'Status do prestador inválido'; END IF;
  v_dest:=CASE WHEN v_status IN ('NOTIFICADO','REEXECUÇÃO CONCLUÍDA') THEN 'MEDICAO' ELSE 'PRESTADOR' END;
  UPDATE public.sigm_civil_chamados SET status_prestador=v_status,status_sigm=v_status,etapa_atual=v_dest,atualizado_em=now() WHERE id=v.id;
  IF v_status IN ('CONCLUÍDO','REEXECUÇÃO CONCLUÍDA') THEN
   INSERT INTO public.sigm_civil_execucoes(chamado_id,numero_tentativa,status,observacao)
   VALUES(v.id,(SELECT count(*)+1 FROM public.sigm_civil_execucoes WHERE chamado_id=v.id),v_status,p_dados->>'observacao');
  END IF;
 ELSIF v_origem='MEDICAO' THEN
  IF v.etapa_atual<>'MEDICAO' THEN RAISE EXCEPTION 'Chamado não está em medição'; END IF;
  IF v_status NOT IN ('EM CONFERÊNCIA','DIVERGÊNCIA DE VALORES','PENDÊNCIA NA EXECUÇÃO','FALTA DOCUMENTOS','DEVOLVIDO PARA REEXECUÇÃO','LANÇADO','PAGO') THEN RAISE EXCEPTION 'Status de medição inválido'; END IF;
  IF v_status='PAGO' AND v.status_medicao<>'LANÇADO' THEN RAISE EXCEPTION 'Só é possível pagar após LANÇADO'; END IF;
  v_num:=nullif(btrim(p_dados->>'numero_medicao'),'');v_val:=nullif(p_dados->>'valor_medicao','')::numeric;
  IF v_status='LANÇADO' AND (v_num IS NULL OR v_val IS NULL OR v_val<0) THEN RAISE EXCEPTION 'Número e valor da medição são obrigatórios'; END IF;
  v_dest:=CASE WHEN v_status='DEVOLVIDO PARA REEXECUÇÃO' THEN 'PRESTADOR' WHEN v_status='PAGO' THEN 'ENCERRADO' ELSE 'MEDICAO' END;
  UPDATE public.sigm_civil_chamados SET status_medicao=v_status,status_sigm=v_status,etapa_atual=v_dest,
    medicao_registrada=CASE WHEN v_status='LANÇADO' THEN true ELSE medicao_registrada END,
    numero_medicao=CASE WHEN v_status='LANÇADO' THEN v_num ELSE numero_medicao END,
    valor_medicao=CASE WHEN v_status='LANÇADO' THEN v_val ELSE valor_medicao END,
    atualizado_em=now() WHERE id=v.id;
  INSERT INTO public.sigm_civil_medicoes(chamado_id,numero_medicao,valor_medicao,status,observacao)
    VALUES(v.id,coalesce(v_num,v.numero_medicao),coalesce(v_val,v.valor_medicao),v_status,p_dados->>'observacao');
 ELSE RAISE EXCEPTION 'Origem de movimentação inválida'; END IF;
 INSERT INTO public.sigm_civil_movimentacoes(chamado_id,origem,destino,status_anterior,status_novo,observacao)
 VALUES(v.id,v_origem,v_dest,v.status_sigm,v_status,p_dados->>'observacao');
 RETURN v.id;
END $$;


COMMIT;
NOTIFY pgrst, 'reload schema';
