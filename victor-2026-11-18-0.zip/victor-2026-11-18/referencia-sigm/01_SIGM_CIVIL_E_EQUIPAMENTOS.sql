-- SIGM-SES | Nova estrutura operacional | 19/10/2026
-- Executar no SQL Editor após backup. NÃO remove nenhuma tabela.
-- Requer: public.usuarios, public.prestadores, public.sigm_unidades_cadastro,
-- public.sigm_setores_cadastro, public.sigm_categorias_civil,
-- public.sigm_config_contratos_civil. Nenhuma service_role no navegador.
BEGIN;

CREATE OR REPLACE FUNCTION public.sigm_operador_civil_autorizado()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
 SELECT EXISTS (
   SELECT 1 FROM public.usuarios u
   WHERE u.ativo IS TRUE AND u.perfil IN ('adm','operador')
     AND (u.auth_uid = (SELECT auth.uid()) OR
          (u.auth_uid IS NULL AND lower(u.email)=lower((SELECT auth.jwt()->>'email'))))
     AND lower(u.email) LIKE '%@joinville.sc.gov.br'
 );
$$;
REVOKE ALL ON FUNCTION public.sigm_operador_civil_autorizado() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sigm_operador_civil_autorizado() TO authenticated;

CREATE TABLE IF NOT EXISTS public.sigm_civil_chamados (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 id_glpi text NOT NULL UNIQUE CHECK (length(btrim(id_glpi)) BETWEEN 1 AND 60),
 prestador_id uuid NOT NULL REFERENCES public.prestadores(id),
 unidade_id bigint NOT NULL REFERENCES public.sigm_unidades_cadastro(id),
 setor_id bigint REFERENCES public.sigm_setores_cadastro(id),
 categoria_id bigint NOT NULL REFERENCES public.sigm_categorias_civil(id),
 data_abertura date NOT NULL,
 descricao text NOT NULL,
 prioridade text NOT NULL CHECK(prioridade IN ('Baixa','Média','Muito Alta')),
 sla_texto text NOT NULL,
 sla_horas numeric(10,2) CHECK(sla_horas IS NULL OR sla_horas > 0),
 inicio_sla timestamptz,
 vence_em timestamptz,
 alerta_em timestamptz,
 tolerancia_minutos integer NOT NULL DEFAULT 30 CHECK(tolerancia_minutos BETWEEN 0 AND 1440),
 status_triagem text NOT NULL CHECK(status_triagem IN ('SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)')),
 status_avaliacao_tecnica text,
 status_prestador text,
 status_medicao text,
 status_sigm text NOT NULL,
 etapa_atual text NOT NULL CHECK(etapa_atual IN ('AVALIACAO','PRESTADOR','MEDICAO','ENCERRADO')),
 medicao_registrada boolean NOT NULL DEFAULT false,
 numero_medicao text,
 valor_medicao numeric(14,2),
 criado_por uuid NOT NULL DEFAULT auth.uid(),
 criado_em timestamptz NOT NULL DEFAULT now(),
 atualizado_em timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sigm_civil_por_prestador ON public.sigm_civil_chamados(prestador_id,etapa_atual,alerta_em);
CREATE INDEX IF NOT EXISTS sigm_civil_por_unidade_categoria ON public.sigm_civil_chamados(unidade_id,categoria_id,medicao_registrada);
CREATE INDEX IF NOT EXISTS sigm_civil_por_etapa ON public.sigm_civil_chamados(etapa_atual,criado_em DESC);

CREATE TABLE IF NOT EXISTS public.sigm_civil_movimentacoes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 chamado_id uuid NOT NULL REFERENCES public.sigm_civil_chamados(id) ON DELETE RESTRICT,
 origem text NOT NULL,
 destino text NOT NULL,
 status_anterior text,
 status_novo text NOT NULL,
 observacao text,
 usuario_id uuid NOT NULL DEFAULT auth.uid(),
 criado_em timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sigm_civil_mov_por_chamado ON public.sigm_civil_movimentacoes(chamado_id,criado_em DESC);

CREATE TABLE IF NOT EXISTS public.sigm_civil_execucoes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 chamado_id uuid NOT NULL REFERENCES public.sigm_civil_chamados(id) ON DELETE RESTRICT,
 numero_tentativa integer NOT NULL CHECK(numero_tentativa > 0),
 status text NOT NULL,
 observacao text,
 documento_url text,
 registrado_por uuid NOT NULL DEFAULT auth.uid(),
 registrado_em timestamptz NOT NULL DEFAULT now(),
 UNIQUE(chamado_id,numero_tentativa)
);
CREATE TABLE IF NOT EXISTS public.sigm_civil_medicoes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 chamado_id uuid NOT NULL REFERENCES public.sigm_civil_chamados(id) ON DELETE RESTRICT,
 numero_medicao text,
 valor_medicao numeric(14,2) CHECK(valor_medicao IS NULL OR valor_medicao >= 0),
 status text NOT NULL,
 observacao text,
 registrado_por uuid NOT NULL DEFAULT auth.uid(),
 registrado_em timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sigm_civil_med_por_chamado ON public.sigm_civil_medicoes(chamado_id,registrado_em DESC);

CREATE TABLE IF NOT EXISTS public.sigm_equipamentos_chamados (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 id_glpi text NOT NULL UNIQUE,
 unidade_id bigint REFERENCES public.sigm_unidades_cadastro(id),
 setor_id bigint REFERENCES public.sigm_setores_cadastro(id),
 equipamento text NOT NULL,
 patrimonio_numero text,
 descricao text NOT NULL,
 prioridade text CHECK(prioridade IN ('Baixa','Média','Muito Alta')),
 status_sigm text NOT NULL DEFAULT 'NOVO',
 criado_por uuid NOT NULL DEFAULT auth.uid(),
 criado_em timestamptz NOT NULL DEFAULT now(),
 atualizado_em timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.sigm_equipamentos_movimentacoes (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 chamado_id uuid NOT NULL REFERENCES public.sigm_equipamentos_chamados(id) ON DELETE RESTRICT,
 status text NOT NULL,
 observacao text,
 usuario_id uuid NOT NULL DEFAULT auth.uid(),
 criado_em timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sigm_equip_mov_por_chamado ON public.sigm_equipamentos_movimentacoes(chamado_id,criado_em DESC);

-- Leitura restrita; escritas operacionais exclusivamente por funções verificadas.
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['sigm_civil_chamados','sigm_civil_movimentacoes','sigm_civil_execucoes','sigm_civil_medicoes','sigm_equipamentos_chamados','sigm_equipamentos_movimentacoes'] LOOP
  EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
  EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated',t);
  EXECUTE format('GRANT SELECT ON public.%I TO authenticated',t);
  EXECUTE format('DROP POLICY IF EXISTS sigm_leitura_institucional ON public.%I',t);
  EXECUTE format('CREATE POLICY sigm_leitura_institucional ON public.%I FOR SELECT TO authenticated USING (public.sigm_operador_civil_autorizado())',t);
 END LOOP;
END $$;

-- Salva a triagem de modo atômico. Não reinicia o SLA em uma edição.
CREATE OR REPLACE FUNCTION public.sigm_civil_salvar_triagem(p_dados jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_id uuid; v_existente public.sigm_civil_chamados%ROWTYPE;
 v_cfg public.sigm_config_contratos_civil%ROWTYPE; v_cat text; v_prazo numeric;
 v_prior text; v_status text; v_dest text; v_inicio timestamptz; v_inicio_efetivo timestamptz;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado à Triagem Civil'; END IF;
 v_prior := p_dados->>'prioridade'; v_status := p_dados->>'status_triagem';
 IF v_prior NOT IN ('Baixa','Média','Muito Alta') OR v_status NOT IN ('SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)') THEN RAISE EXCEPTION 'Prioridade ou status inválido'; END IF;
 IF nullif(btrim(p_dados->>'id_glpi'),'') IS NULL OR nullif(btrim(p_dados->>'descricao'),'') IS NULL THEN RAISE EXCEPTION 'GLPI e descrição são obrigatórios'; END IF;
 SELECT * INTO v_cfg FROM public.sigm_config_contratos_civil WHERE prestador_id=(p_dados->>'prestador_id')::uuid;
 IF NOT FOUND THEN RAISE EXCEPTION 'Prestador sem configuração contratual'; END IF;
 SELECT nome INTO v_cat FROM public.sigm_categorias_civil WHERE id=(p_dados->>'categoria_id')::bigint AND ativo IS TRUE;
 IF v_cat IS NULL OR NOT (to_jsonb(v_cfg.categorias) ? v_cat) THEN RAISE EXCEPTION 'Categoria não autorizada no contrato'; END IF;
 IF v_prior='Média' THEN v_prazo:=v_cfg.sla_media_horas;
 ELSIF v_prior='Muito Alta' THEN v_prazo:=v_cfg.sla_muito_alta_horas;
 ELSE v_prazo:=NULL; END IF;
 IF v_prior<>'Baixa' AND (v_prazo IS NULL OR v_prazo<=0) THEN RAISE EXCEPTION 'Prazo SLA inválido no contrato'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.sigm_setores_cadastro s WHERE s.id=nullif(p_dados->>'setor_id','')::bigint AND s.unidade_id=(p_dados->>'unidade_id')::bigint) AND nullif(p_dados->>'setor_id','') IS NOT NULL THEN
   RAISE EXCEPTION 'Setor não pertence à unidade selecionada'; END IF;
 v_dest:=CASE WHEN v_status='SOLICITO AVALIAÇÃO TÉCNICA' THEN 'AVALIACAO' ELSE 'PRESTADOR' END;
 SELECT * INTO v_existente FROM public.sigm_civil_chamados WHERE id_glpi=p_dados->>'id_glpi' FOR UPDATE;
 IF FOUND THEN
   IF (v_existente.inicio_sla IS NOT NULL AND v_dest='AVALIACAO') OR v_existente.etapa_atual NOT IN ('AVALIACAO','PRESTADOR') OR v_existente.status_prestador IS NOT NULL OR v_existente.status_medicao IS NOT NULL THEN
     RAISE EXCEPTION 'Chamado já avançou no fluxo; use o módulo responsável'; END IF;
   UPDATE public.sigm_civil_chamados SET
    prestador_id=(p_dados->>'prestador_id')::uuid,unidade_id=(p_dados->>'unidade_id')::bigint,
    setor_id=nullif(p_dados->>'setor_id','')::bigint,categoria_id=(p_dados->>'categoria_id')::bigint,
    data_abertura=(p_dados->>'data_abertura')::date,descricao=p_dados->>'descricao',
    prioridade=v_prior,sla_texto=CASE WHEN v_prior='Baixa' THEN coalesce(v_cfg.sla_baixa_texto,'Programado') ELSE v_prazo::text||' horas' END,
    sla_horas=v_prazo,
    inicio_sla=CASE WHEN v_dest='PRESTADOR' THEN coalesce(v_existente.inicio_sla,now()) ELSE v_existente.inicio_sla END,
    vence_em=CASE WHEN v_dest='PRESTADOR' AND v_prazo IS NOT NULL THEN coalesce(v_existente.inicio_sla,now())+(v_prazo*interval '1 hour') ELSE NULL END,
    alerta_em=CASE WHEN v_dest='PRESTADOR' AND v_prazo IS NOT NULL THEN coalesce(v_existente.inicio_sla,now())+(v_prazo*interval '1 hour')+interval '30 minutes' ELSE NULL END,
    status_triagem=v_status,status_sigm=v_status,etapa_atual=v_dest,atualizado_em=now()
   WHERE id=v_existente.id RETURNING id INTO v_id;
 ELSE
   v_inicio:=CASE WHEN v_dest='PRESTADOR' THEN now() ELSE NULL END;
   INSERT INTO public.sigm_civil_chamados
    (id_glpi,prestador_id,unidade_id,setor_id,categoria_id,data_abertura,descricao,prioridade,sla_texto,sla_horas,inicio_sla,vence_em,alerta_em,status_triagem,status_sigm,etapa_atual)
   VALUES (p_dados->>'id_glpi',(p_dados->>'prestador_id')::uuid,(p_dados->>'unidade_id')::bigint,nullif(p_dados->>'setor_id','')::bigint,
    (p_dados->>'categoria_id')::bigint,(p_dados->>'data_abertura')::date,p_dados->>'descricao',v_prior,
    CASE WHEN v_prior='Baixa' THEN coalesce(v_cfg.sla_baixa_texto,'Programado') ELSE v_prazo::text||' horas' END,
    v_prazo,v_inicio,CASE WHEN v_inicio IS NULL OR v_prazo IS NULL THEN NULL ELSE v_inicio+(v_prazo*interval '1 hour') END,
    CASE WHEN v_inicio IS NULL OR v_prazo IS NULL THEN NULL ELSE v_inicio+(v_prazo*interval '1 hour')+interval '30 minutes' END,v_status,v_status,v_dest)
   RETURNING id INTO v_id;
 END IF;
 INSERT INTO public.sigm_civil_movimentacoes(chamado_id,origem,destino,status_anterior,status_novo,observacao)
 VALUES(v_id,'TRIAGEM',v_dest,v_existente.status_sigm,v_status,'Triagem salva pelo usuário autenticado');
 RETURN v_id;
END $$;

-- Movimentações de execução/medição, com controle de origem e status.
CREATE OR REPLACE FUNCTION public.sigm_civil_atualizar_status(p_dados jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v public.sigm_civil_chamados%ROWTYPE; v_status text; v_origem text; v_dest text; v_num text; v_val numeric;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
 SELECT * INTO v FROM public.sigm_civil_chamados WHERE id=(p_dados->>'chamado_id')::uuid FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Chamado não encontrado'; END IF;
 v_origem:=p_dados->>'origem'; v_status:=p_dados->>'status';v_dest:=v.etapa_atual;
 IF nullif(btrim(p_dados->>'observacao'),'') IS NULL THEN RAISE EXCEPTION 'Justificativa obrigatória'; END IF;
 IF v_origem='AVALIACAO' THEN
  IF v.etapa_atual<>'AVALIACAO' THEN RAISE EXCEPTION 'Chamado não está em avaliação'; END IF;
  IF v_status NOT IN ('LIBERADO PARA ATENDIMENTO (PLANEJADO)','UNIFICADO','DUPLICADO','EM ANÁLISE','ENCERRADO','OUTRO PRESTADOR') THEN RAISE EXCEPTION 'Status de avaliação inválido'; END IF;
  v_dest:=CASE WHEN v_status='LIBERADO PARA ATENDIMENTO (PLANEJADO)' THEN 'PRESTADOR' WHEN v_status IN ('ENCERRADO','UNIFICADO','DUPLICADO') THEN 'ENCERRADO' ELSE 'AVALIACAO' END;
  UPDATE public.sigm_civil_chamados SET status_avaliacao_tecnica=v_status,status_sigm=v_status,etapa_atual=v_dest,
    inicio_sla=CASE WHEN v_dest='PRESTADOR' THEN coalesce(inicio_sla,now()) ELSE inicio_sla END,
    vence_em=CASE WHEN v_dest='PRESTADOR' AND sla_horas IS NOT NULL THEN coalesce(inicio_sla,now())+sla_horas*interval '1 hour' ELSE vence_em END,
    alerta_em=CASE WHEN v_dest='PRESTADOR' AND sla_horas IS NOT NULL THEN coalesce(inicio_sla,now())+sla_horas*interval '1 hour'+tolerancia_minutos*interval '1 minute' ELSE alerta_em END,
    atualizado_em=now() WHERE id=v.id;
 ELSIF v_origem='PRESTADOR' THEN
  IF v.etapa_atual<>'PRESTADOR' THEN RAISE EXCEPTION 'Chamado não está com prestador'; END IF;
  IF v_status NOT IN ('EM EXECUÇÃO','CONCLUÍDO','NOTIFICADO','PENDENTE DOCUMENTAÇÃO DE ORDEM DE SERVIÇO','EM REEXECUÇÃO','REEXECUÇÃO CONCLUÍDA') THEN RAISE EXCEPTION 'Status do prestador inválido'; END IF;
  v_dest:=CASE WHEN v_status IN ('NOTIFICADO','REEXECUÇÃO CONCLUÍDA') THEN 'MEDICAO' ELSE 'PRESTADOR' END;
  UPDATE public.sigm_civil_chamados SET status_prestador=v_status,status_sigm=v_status,etapa_atual=v_dest,atualizado_em=now() WHERE id=v.id;
  IF v_status IN ('CONCLUÍDO','REEXECUÇÃO CONCLUÍDA') THEN
   INSERT INTO public.sigm_civil_execucoes(chamado_id,numero_tentativa,status,observacao)
   VALUES(v.id,(SELECT count(*)+1 FROM public.sigm_civil_execucoes WHERE chamado_id=v.id),v_status,p_dados->>'observacao');
  END IF;
 ELSIF v_origem='MEDICAO' THEN
  IF v.etapa_atual<>'MEDICAO' THEN RAISE EXCEPTION 'Chamado não está em medição'; END IF;
  IF v_status NOT IN ('EM CONFERÊNCIA','DIVERGÊNCIA DE VALORES','PENDÊNCIA NA EXECUÇÃO','FALTA DOCUMENTOS','DEVOLVIDO PARA REEXECUÇÃO','LANÇADO','PAGO') THEN RAISE EXCEPTION 'Status de medição inválido'; END IF;
  IF v_status='PAGO' AND v.status_medicao<>'LANÇADO' THEN RAISE EXCEPTION 'Só é possível pagar após LANÇADO'; END IF;
  v_num:=nullif(btrim(p_dados->>'numero_medicao'),'');v_val:=nullif(p_dados->>'valor_medicao','')::numeric;
  IF v_status='LANÇADO' AND (v_num IS NULL OR v_val IS NULL OR v_val<0) THEN RAISE EXCEPTION 'Número e valor da medição são obrigatórios'; END IF;
  v_dest:=CASE WHEN v_status='DEVOLVIDO PARA REEXECUÇÃO' THEN 'PRESTADOR' WHEN v_status='PAGO' THEN 'ENCERRADO' ELSE 'MEDICAO' END;
  UPDATE public.sigm_civil_chamados SET status_medicao=v_status,status_sigm=v_status,etapa_atual=v_dest,
    medicao_registrada=CASE WHEN v_status='LANÇADO' THEN true ELSE medicao_registrada END,
    numero_medicao=CASE WHEN v_status='LANÇADO' THEN v_num ELSE numero_medicao END,
    valor_medicao=CASE WHEN v_status='LANÇADO' THEN v_val ELSE valor_medicao END,
    atualizado_em=now() WHERE id=v.id;
  INSERT INTO public.sigm_civil_medicoes(chamado_id,numero_medicao,valor_medicao,status,observacao)
    VALUES(v.id,coalesce(v_num,v.numero_medicao),coalesce(v_val,v.valor_medicao),v_status,p_dados->>'observacao');
 ELSE RAISE EXCEPTION 'Origem de movimentação inválida'; END IF;
 INSERT INTO public.sigm_civil_movimentacoes(chamado_id,origem,destino,status_anterior,status_novo,observacao)
 VALUES(v.id,v_origem,v_dest,v.status_sigm,v_status,p_dados->>'observacao');
 RETURN v.id;
END $$;

CREATE OR REPLACE FUNCTION public.sigm_equipamentos_salvar(p_dados jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_id uuid;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
 IF nullif(btrim(p_dados->>'id_glpi'),'') IS NULL OR nullif(btrim(p_dados->>'equipamento'),'') IS NULL OR nullif(btrim(p_dados->>'descricao'),'') IS NULL THEN RAISE EXCEPTION 'GLPI, equipamento e descrição são obrigatórios'; END IF;
 INSERT INTO public.sigm_equipamentos_chamados(id_glpi,unidade_id,setor_id,equipamento,patrimonio_numero,descricao,prioridade)
 VALUES(p_dados->>'id_glpi',nullif(p_dados->>'unidade_id','')::bigint,nullif(p_dados->>'setor_id','')::bigint,p_dados->>'equipamento',p_dados->>'patrimonio_numero',p_dados->>'descricao',nullif(p_dados->>'prioridade',''))
 ON CONFLICT(id_glpi) DO NOTHING RETURNING id INTO v_id;
 IF v_id IS NULL THEN RAISE EXCEPTION 'Este GLPI já existe em Equipamentos'; END IF;
 INSERT INTO public.sigm_equipamentos_movimentacoes(chamado_id,status,observacao) VALUES(v_id,'NOVO','Cadastro inicial');
 RETURN v_id;
END $$;
CREATE OR REPLACE FUNCTION public.sigm_equipamentos_atualizar(p_id uuid,p_status text,p_observacao text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
 IF p_status NOT IN ('NOVO','EM AVALIAÇÃO','EM MANUTENÇÃO','AGUARDANDO LAUDO','CONCLUÍDO','ENCERRADO') OR nullif(btrim(p_observacao),'') IS NULL THEN RAISE EXCEPTION 'Status ou justificativa inválidos'; END IF;
 UPDATE public.sigm_equipamentos_chamados SET status_sigm=p_status,atualizado_em=now() WHERE id=p_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'Chamado não encontrado'; END IF;
 INSERT INTO public.sigm_equipamentos_movimentacoes(chamado_id,status,observacao) VALUES(p_id,p_status,p_observacao);
 RETURN p_id;
END $$;

DO $$ DECLARE f text; BEGIN
 FOREACH f IN ARRAY ARRAY['sigm_civil_salvar_triagem(jsonb)','sigm_civil_atualizar_status(jsonb)','sigm_equipamentos_salvar(jsonb)','sigm_equipamentos_atualizar(uuid,text,text)'] LOOP
  EXECUTE 'REVOKE ALL ON FUNCTION public.'||f||' FROM PUBLIC';
  EXECUTE 'GRANT EXECUTE ON FUNCTION public.'||f||' TO authenticated';
 END LOOP;
END $$;
COMMIT;
NOTIFY pgrst, 'reload schema';
