// Entrada da página Triagem Civil.
// O motor comum permanece em ../app.js para preservar as regras existentes.
window.SIGM_PAGE_ID = "triagem-civil";
await import('../app.js?v=20261020-login-senha-v2');
