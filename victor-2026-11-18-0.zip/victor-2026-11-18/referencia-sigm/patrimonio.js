// Entrada da página Patrimônio.
// O motor comum permanece em ../app.js para preservar as regras existentes.
window.SIGM_PAGE_ID = "patrimonio";
await import('../app.js?v=20261020-login-senha-v2');
