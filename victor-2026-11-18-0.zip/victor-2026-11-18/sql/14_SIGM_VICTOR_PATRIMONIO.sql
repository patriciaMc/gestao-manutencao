-- Complemento opcional: cadastro patrimonial desta interface sobre a tabela do SIGM.
-- Conferir tipos/constraints da tabela existente em homologação; não é migração do projeto Prisma do Victor.
BEGIN;
ALTER TABLE public.sigm_patrimonios_cadastro ADD COLUMN IF NOT EXISTS categoria_nome text;
ALTER TABLE public.sigm_patrimonios_cadastro ADD COLUMN IF NOT EXISTS familia_nome text;
-- Se houver tombamentos duplicados antigos, revisar manualmente antes de criar o índice. Não apaga duplicatas.
CREATE UNIQUE INDEX IF NOT EXISTS sigm_v4_patrimonio_unico ON public.sigm_patrimonios_cadastro(lower(btrim(patrimonio_serie))) WHERE nullif(btrim(patrimonio_serie),'') IS NOT NULL;
CREATE OR REPLACE FUNCTION public.sigm_v4_cadastrar_patrimonio(p_dados jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE r jsonb; unidade bigint;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() OR NOT EXISTS(SELECT 1 FROM public.usuarios u WHERE u.ativo IS TRUE AND u.perfil='adm' AND (u.auth_uid=auth.uid() OR (u.auth_uid IS NULL AND lower(u.email)=lower(auth.jwt()->>'email')))) THEN RAISE EXCEPTION 'Cadastro patrimonial restrito à administração'; END IF;
 IF nullif(btrim(p_dados->>'tombamento'),'') IS NULL OR length(p_dados->>'tombamento')>100 OR length(btrim(coalesce(p_dados->>'descricao','')))<2 OR length(p_dados->>'descricao')>2000 OR nullif(btrim(p_dados->>'categoria_nome'),'') IS NULL OR nullif(btrim(p_dados->>'familia_nome'),'') IS NULL THEN RAISE EXCEPTION 'Preencha tombamento, descrição, categoria e família'; END IF;
 unidade:=(p_dados->>'unidade_id')::bigint;
 IF NOT EXISTS(SELECT 1 FROM public.sigm_unidades_cadastro WHERE id=unidade) THEN RAISE EXCEPTION 'Unidade inválida'; END IF;
 WITH novo AS (
  INSERT INTO public.sigm_patrimonios_cadastro(patrimonio_serie,descricao,unidade_id,estado_conservacao,situacao_atual,categoria_nome,familia_nome)
  VALUES(btrim(p_dados->>'tombamento'),btrim(p_dados->>'descricao'),unidade,'Bom','Ativo',btrim(p_dados->>'categoria_nome'),btrim(p_dados->>'familia_nome')) RETURNING *
 ) SELECT to_jsonb(n) INTO r FROM novo n;
 RETURN r;
EXCEPTION WHEN unique_violation THEN RAISE EXCEPTION 'Este tombamento já está cadastrado';
END $$;
REVOKE ALL ON FUNCTION public.sigm_v4_cadastrar_patrimonio(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sigm_v4_cadastrar_patrimonio(jsonb) TO authenticated;
COMMIT;
