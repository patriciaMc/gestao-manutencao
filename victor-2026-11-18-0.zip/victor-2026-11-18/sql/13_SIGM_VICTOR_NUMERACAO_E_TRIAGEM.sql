-- Versão de integração sobre SIGM3.0 (backup de 20/10/2026).
-- Revisar em homologação após os scripts estruturais 01 a 12. Não executar no projeto do Victor/PostgreSQL Prisma.
-- Preserva GLPI histórico. Chamados novos usam número interno e não precisam de GLPI.
BEGIN;
CREATE SEQUENCE IF NOT EXISTS public.sigm_v4_civil_numero_seq;
CREATE SEQUENCE IF NOT EXISTS public.sigm_v4_equip_numero_seq;
CREATE OR REPLACE FUNCTION public.sigm_v4_proximo_numero(p_familia text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE n bigint; prefixo text;
BEGIN
 IF p_familia='CIVIL' THEN n:=nextval('public.sigm_v4_civil_numero_seq');prefixo:='CIV';
 ELSIF p_familia='EQUIPAMENTOS' THEN n:=nextval('public.sigm_v4_equip_numero_seq');prefixo:='EQP';
 ELSE RAISE EXCEPTION 'Família inválida'; END IF;
 RETURN prefixo||'-'||to_char(current_date,'YYYY')||'-'||lpad(n::text,greatest(6,length(n::text)),'0');
END $$;
REVOKE ALL ON FUNCTION public.sigm_v4_proximo_numero(text) FROM PUBLIC;
ALTER TABLE public.sigm_civil_chamados ALTER COLUMN id_glpi DROP NOT NULL;
ALTER TABLE public.sigm_equipamentos_chamados ALTER COLUMN id_glpi DROP NOT NULL;
ALTER TABLE public.sigm_civil_chamados ADD COLUMN IF NOT EXISTS numero_chamado text;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS numero_chamado text;
ALTER TABLE public.sigm_civil_chamados ALTER COLUMN numero_chamado SET DEFAULT public.sigm_v4_proximo_numero('CIVIL');
ALTER TABLE public.sigm_equipamentos_chamados ALTER COLUMN numero_chamado SET DEFAULT public.sigm_v4_proximo_numero('EQUIPAMENTOS');
UPDATE public.sigm_civil_chamados SET numero_chamado=DEFAULT WHERE numero_chamado IS NULL;
UPDATE public.sigm_equipamentos_chamados SET numero_chamado=DEFAULT WHERE numero_chamado IS NULL;
ALTER TABLE public.sigm_civil_chamados ALTER COLUMN numero_chamado SET NOT NULL;
ALTER TABLE public.sigm_equipamentos_chamados ALTER COLUMN numero_chamado SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS sigm_v4_civil_numero ON public.sigm_civil_chamados(numero_chamado);
CREATE UNIQUE INDEX IF NOT EXISTS sigm_v4_equip_numero ON public.sigm_equipamentos_chamados(numero_chamado);
ALTER TABLE public.sigm_civil_chamados ADD COLUMN IF NOT EXISTS requisicao_id uuid;
ALTER TABLE public.sigm_civil_chamados ADD COLUMN IF NOT EXISTS requisicao_dados jsonb;
ALTER TABLE public.sigm_civil_chamados ADD COLUMN IF NOT EXISTS setores_texto text;
ALTER TABLE public.sigm_civil_chamados ADD COLUMN IF NOT EXISTS observacao text;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS requisicao_id uuid;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS requisicao_dados jsonb;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS categoria_id text;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS categoria_nome text;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS prestador_id uuid REFERENCES public.prestadores(id);
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS data_abertura date;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS setores_texto text;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS observacao text;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS sla_horas numeric(10,2) CHECK(sla_horas IS NULL OR sla_horas>0);
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS inicio_sla timestamptz;
ALTER TABLE public.sigm_equipamentos_chamados ADD COLUMN IF NOT EXISTS vence_em timestamptz;
CREATE UNIQUE INDEX IF NOT EXISTS sigm_v4_civil_requisicao ON public.sigm_civil_chamados(requisicao_id) WHERE requisicao_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS sigm_v4_equip_requisicao ON public.sigm_equipamentos_chamados(requisicao_id) WHERE requisicao_id IS NOT NULL;

-- Políticas de Equipamentos precisam de revisão contratual antes de liberar na base real.
CREATE TABLE IF NOT EXISTS public.sigm_v4_politicas_sla (
 familia text PRIMARY KEY CHECK(familia IN ('CIVIL','EQUIPAMENTOS')),
 media_horas numeric NOT NULL CHECK(media_horas>0),
 muito_alta_horas numeric NOT NULL CHECK(muito_alta_horas>0),
 revisada boolean NOT NULL DEFAULT false
);
INSERT INTO public.sigm_v4_politicas_sla(familia,media_horas,muito_alta_horas) VALUES ('CIVIL',48,2),('EQUIPAMENTOS',48,2) ON CONFLICT DO NOTHING;
ALTER TABLE public.sigm_v4_politicas_sla ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.sigm_v4_politicas_sla FROM anon,authenticated;
GRANT SELECT ON public.sigm_v4_politicas_sla TO authenticated;
DROP POLICY IF EXISTS sigm_v4_leitura_sla ON public.sigm_v4_politicas_sla;
CREATE POLICY sigm_v4_leitura_sla ON public.sigm_v4_politicas_sla FOR SELECT TO authenticated USING(public.sigm_operador_civil_autorizado());

CREATE OR REPLACE FUNCTION public.sigm_v4_criar_triagem(p_dados jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE f text:=p_dados->>'familia'; st text:=p_dados->>'status_sigm'; pr text:=p_dados->>'prioridade';
 v uuid; existente jsonb; unidade bigint; prest uuid; cat bigint; nome_cat text; prazo numeric; inicio timestamptz;
 cfg public.sigm_config_contratos_civil%ROWTYPE; pol public.sigm_v4_politicas_sla%ROWTYPE; resultado jsonb;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
 IF f NOT IN ('CIVIL','EQUIPAMENTOS') OR f IS NULL OR st NOT IN ('SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)') OR st IS NULL OR pr NOT IN ('Baixa','Média','Muito Alta') OR pr IS NULL THEN RAISE EXCEPTION 'Família, status ou prioridade inválidos'; END IF;
 IF pg_column_size(p_dados)>50000 THEN RAISE EXCEPTION 'Requisição muito grande'; END IF;
 IF length(btrim(coalesce(p_dados->>'descricao','')))<5 OR length(p_dados->>'descricao')>20000 THEN RAISE EXCEPTION 'Descrição deve ter de 5 a 20000 caracteres'; END IF;
 IF nullif(p_dados->>'requisicao_id','') IS NULL THEN RAISE EXCEPTION 'Chave de requisição ausente'; END IF;
 -- Serializa somente reenvios da mesma requisição; a sequência garante a numeração entre requisições distintas.
 PERFORM pg_advisory_xact_lock(hashtextextended(p_dados->>'requisicao_id',0));
 IF f='CIVIL' THEN SELECT to_jsonb(c) INTO existente FROM public.sigm_civil_chamados c WHERE requisicao_id=(p_dados->>'requisicao_id')::uuid;
 ELSE SELECT to_jsonb(c) INTO existente FROM public.sigm_equipamentos_chamados c WHERE requisicao_id=(p_dados->>'requisicao_id')::uuid; END IF;
 IF existente IS NOT NULL THEN IF existente->'requisicao_dados'<>p_dados THEN RAISE EXCEPTION 'Reenvio com dados diferentes'; END IF; RETURN existente; END IF;
 unidade:=(p_dados->>'unidade_id')::bigint;
 IF unidade IS NULL OR NOT EXISTS(SELECT 1 FROM public.sigm_unidades_cadastro WHERE id=unidade) THEN RAISE EXCEPTION 'Unidade inválida'; END IF;
 prest:=nullif(p_dados->>'prestador_id','')::uuid;
 IF prest IS NOT NULL AND NOT EXISTS(SELECT 1 FROM public.prestadores WHERE id=prest) THEN RAISE EXCEPTION 'Prestador inválido'; END IF;
 IF f='CIVIL' THEN
  cat:=(p_dados->>'categoria_id')::bigint;
  SELECT nome INTO nome_cat FROM public.sigm_categorias_civil WHERE id=cat AND ativo IS TRUE;
  IF nome_cat IS NULL THEN RAISE EXCEPTION 'Categoria inválida ou inativa'; END IF;
  SELECT * INTO cfg FROM public.sigm_config_contratos_civil WHERE prestador_id=prest;
  IF NOT FOUND OR NOT(to_jsonb(cfg.categorias)?nome_cat) THEN RAISE EXCEPTION 'Prestador sem configuração ou categoria fora do contrato'; END IF;
  prazo:=CASE WHEN pr='Baixa' THEN NULL WHEN pr='Muito Alta' THEN cfg.sla_muito_alta_horas ELSE cfg.sla_media_horas END;
 ELSE
  IF nullif(btrim(p_dados->>'equipamento'),'') IS NULL OR p_dados->>'categoria_id' NOT IN ('climatizacao','saude') OR p_dados->>'categoria_id' IS NULL THEN RAISE EXCEPTION 'Equipamento ou categoria inválidos'; END IF;
  SELECT * INTO pol FROM public.sigm_v4_politicas_sla WHERE familia='EQUIPAMENTOS';
  IF st='LIBERADO PARA ATENDIMENTO (PLANEJADO)' AND (prest IS NULL OR NOT coalesce(pol.revisada,false)) THEN RAISE EXCEPTION 'Selecione prestador e revise a política SLA de Equipamentos antes de liberar'; END IF;
  prazo:=CASE WHEN pr='Baixa' THEN NULL WHEN pr='Muito Alta' THEN pol.muito_alta_horas ELSE pol.media_horas END;
 END IF;
 IF pr<>'Baixa' AND (prazo IS NULL OR prazo<=0) THEN RAISE EXCEPTION 'Prazo SLA não configurado'; END IF;
 inicio:=CASE WHEN st='LIBERADO PARA ATENDIMENTO (PLANEJADO)' THEN now() ELSE NULL END;
 IF f='CIVIL' THEN
  INSERT INTO public.sigm_civil_chamados(prestador_id,unidade_id,categoria_id,data_abertura,descricao,prioridade,sla_texto,sla_horas,inicio_sla,vence_em,alerta_em,status_triagem,status_sigm,etapa_atual,requisicao_id,requisicao_dados,setores_texto)
  VALUES(prest,unidade,cat,(p_dados->>'data_abertura')::date,p_dados->>'descricao',pr,CASE WHEN prazo IS NULL THEN 'Planejado' ELSE prazo::text||'h' END,prazo,inicio,inicio+prazo*interval '1 hour',inicio+prazo*interval '1 hour'+interval '30 minutes',st,st,CASE WHEN inicio IS NULL THEN 'AVALIACAO' ELSE 'PRESTADOR' END,(p_dados->>'requisicao_id')::uuid,p_dados,p_dados->>'setores_texto') RETURNING id INTO v;
  INSERT INTO public.sigm_civil_movimentacoes(chamado_id,origem,destino,status_novo,observacao) VALUES(v,'TRIAGEM',CASE WHEN inicio IS NULL THEN 'AVALIACAO' ELSE 'PRESTADOR' END,st,'Chamado criado com numeração própria; sem exigência de GLPI.');
  SELECT to_jsonb(c) INTO resultado FROM public.sigm_civil_chamados c WHERE id=v;
 ELSE
  INSERT INTO public.sigm_equipamentos_chamados(unidade_id,equipamento,patrimonio_numero,descricao,prioridade,status_sigm,categoria_id,categoria_nome,prestador_id,data_abertura,setores_texto,sla_horas,inicio_sla,vence_em,requisicao_id,requisicao_dados)
  VALUES(unidade,p_dados->>'equipamento',p_dados->>'patrimonio_numero',p_dados->>'descricao',pr,st,p_dados->>'categoria_id',CASE WHEN p_dados->>'categoria_id'='climatizacao' THEN 'Climatização' ELSE 'Equipamentos de saúde' END,prest,(p_dados->>'data_abertura')::date,p_dados->>'setores_texto',prazo,inicio,inicio+prazo*interval '1 hour',(p_dados->>'requisicao_id')::uuid,p_dados) RETURNING id INTO v;
  INSERT INTO public.sigm_equipamentos_movimentacoes(chamado_id,status,observacao) VALUES(v,st,'Chamado criado com numeração própria.');
  SELECT to_jsonb(c) INTO resultado FROM public.sigm_equipamentos_chamados c WHERE id=v;
 END IF;
 RETURN resultado;
END $$;
REVOKE ALL ON FUNCTION public.sigm_v4_criar_triagem(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sigm_v4_criar_triagem(jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.sigm_v4_atualizar_status(p_familia text,p_id uuid,p_status text,p_observacao text,p_versao timestamptz)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE r jsonb; resultado jsonb; inicio timestamptz; prazo numeric; destino text; pol public.sigm_v4_politicas_sla%ROWTYPE;
BEGIN
 IF NOT public.sigm_operador_civil_autorizado() THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
 IF p_familia NOT IN ('CIVIL','EQUIPAMENTOS') OR p_familia IS NULL OR p_status IS NULL OR p_status NOT IN ('SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)','AGENDADO VISITA','AGUARDANDO RESPOSTA VIA SISTEMA','EM ROTA','EM EXECUÇÃO','EXECUTADO','PAGO','CANCELADO') OR length(btrim(coalesce(p_observacao,'')))<1 OR length(p_observacao)>10000 THEN RAISE EXCEPTION 'Status, família ou observação inválidos'; END IF;
 IF p_familia='CIVIL' THEN SELECT to_jsonb(c) INTO r FROM public.sigm_civil_chamados c WHERE id=p_id FOR UPDATE;
 ELSE SELECT to_jsonb(c) INTO r FROM public.sigm_equipamentos_chamados c WHERE id=p_id FOR UPDATE; END IF;
 IF r IS NULL THEN RAISE EXCEPTION 'Chamado não encontrado'; END IF;
 IF p_versao IS DISTINCT FROM (r->>'atualizado_em')::timestamptz THEN RAISE EXCEPTION 'Chamado alterado por outra pessoa; reabra o detalhe'; END IF;
 IF r->>'status_sigm' IN ('EXECUTADO','PAGO','CANCELADO','CONCLUÍDO','ENCERRADO','UNIFICADO','DUPLICADO') THEN RAISE EXCEPTION 'Chamado encerrado: use os módulos específicos de medição e encerramento do SIGM'; END IF;
 IF p_status='PAGO' THEN RAISE EXCEPTION 'Registre pagamento no módulo de medição original, com os valores e validações contratuais'; END IF;
 inicio:=(r->>'inicio_sla')::timestamptz;prazo:=(r->>'sla_horas')::numeric;
 IF inicio IS NULL AND p_status IN ('LIBERADO PARA ATENDIMENTO (PLANEJADO)','EM ROTA','EM EXECUÇÃO') THEN
  IF nullif(r->>'prestador_id','') IS NULL THEN RAISE EXCEPTION 'Vincule o prestador antes de liberar este chamado'; END IF;
  IF p_familia='EQUIPAMENTOS' THEN SELECT * INTO pol FROM public.sigm_v4_politicas_sla WHERE familia='EQUIPAMENTOS';IF NOT coalesce(pol.revisada,false) THEN RAISE EXCEPTION 'Política SLA de Equipamentos ainda não revisada'; END IF; END IF;
  IF r->>'prioridade'<>'Baixa' AND (prazo IS NULL OR prazo<=0) THEN RAISE EXCEPTION 'Prazo SLA ausente. Revise o chamado antes de liberar'; END IF;
  inicio:=now();
 END IF;
 destino:=CASE WHEN p_status IN ('EXECUTADO') THEN 'MEDICAO' WHEN p_status IN ('CANCELADO') THEN 'ENCERRADO' WHEN p_status IN ('LIBERADO PARA ATENDIMENTO (PLANEJADO)','EM ROTA','EM EXECUÇÃO') THEN 'PRESTADOR' ELSE 'AVALIACAO' END;
 IF p_familia='CIVIL' THEN
  UPDATE public.sigm_civil_chamados SET status_sigm=p_status,status_prestador=CASE WHEN destino IN ('PRESTADOR','MEDICAO') THEN p_status ELSE status_prestador END,etapa_atual=destino,inicio_sla=inicio,vence_em=CASE WHEN inicio IS NOT NULL THEN coalesce(vence_em,inicio+prazo*interval '1 hour') ELSE vence_em END,alerta_em=CASE WHEN inicio IS NOT NULL AND prazo IS NOT NULL THEN coalesce(alerta_em,inicio+prazo*interval '1 hour'+tolerancia_minutos*interval '1 minute') ELSE alerta_em END,observacao=p_observacao,atualizado_em=now() WHERE id=p_id;
  INSERT INTO public.sigm_civil_movimentacoes(chamado_id,origem,destino,status_anterior,status_novo,observacao) VALUES(p_id,r->>'etapa_atual',destino,r->>'status_sigm',p_status,p_observacao);
  SELECT to_jsonb(c) INTO resultado FROM public.sigm_civil_chamados c WHERE id=p_id;
 ELSE
  UPDATE public.sigm_equipamentos_chamados SET status_sigm=p_status,inicio_sla=inicio,vence_em=CASE WHEN inicio IS NOT NULL THEN coalesce(vence_em,inicio+prazo*interval '1 hour') ELSE vence_em END,observacao=p_observacao,atualizado_em=now() WHERE id=p_id;
  INSERT INTO public.sigm_equipamentos_movimentacoes(chamado_id,status,observacao) VALUES(p_id,p_status,p_observacao);
  SELECT to_jsonb(c) INTO resultado FROM public.sigm_equipamentos_chamados c WHERE id=p_id;
 END IF;
 RETURN resultado;
END $$;
REVOKE ALL ON FUNCTION public.sigm_v4_atualizar_status(text,uuid,text,text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sigm_v4_atualizar_status(text,uuid,text,text,timestamptz) TO authenticated;
COMMIT;
