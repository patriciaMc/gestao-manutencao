# Integração do SIGM em homologação

A versão roda sem rede externa em modo demo. Para dados reais, o programador precisa validar a estrutura e configurar a própria base de teste.

## Pré-requisitos

- Base Supabase do SIGM com os scripts estruturais e permissões do backup aplicados/revisados.
- Tabelas sigm_civil_chamados, sigm_equipamentos_chamados, respectivas movimentações, usuarios, prestadores, sigm_unidades_cadastro, sigm_categorias_civil, sigm_config_contratos_civil e sigm_patrimonios_cadastro.
- Função sigm_operador_civil_autorizado(), que confere usuário ativo, perfil adm/operador e vínculo com a conta institucional conforme a base anterior.
- Backup do banco e base de homologação. Esta entrega não aplica migrações remotamente.

## Sequência

1. Revisar schema, FKs e valores de CHECK/enum da base real contra os scripts de referência.
2. Aplicar 13_SIGM_VICTOR_NUMERACAO_E_TRIAGEM.sql em homologação. Ele remove só a obrigatoriedade de id_glpi, mantém valores antigos e atribui número próprio aos registros existentes que ainda não têm número.
3. Conferir as sequências e unicidade de numero_chamado. Lacunas são normais em transações revertidas; números não são reutilizados nem reiniciados na troca de ano.
4. Civil usa os prazos e categorias do contrato do prestador. Conferir as configurações antes de abrir/liberar.
5. Revisar o SLA de Equipamentos com a administração e só então atualizar a linha EQUIPAMENTOS em sigm_v4_politicas_sla, incluindo revisada=true. O script não faz essa aprovação automaticamente.
6. Se usar o cadastro patrimonial desta interface, revisar/aplicar 14_SIGM_VICTOR_PATRIMONIO.sql. A tabela de origem usa patrimonio_serie, descricao, unidade_id, estado_conservacao e situacao_atual; confira se os valores 'Bom' e 'Ativo' são aceitos pelo schema real. O script acrescenta categoria_nome e familia_nome como metadados de classificação, sem classificar automaticamente os bens antigos. O índice único recusa tombamentos antigos duplicados; revisar as duplicatas, sem apagá-las para forçar a migração.
7. Copiar config.example.js para config.js, definir modo='supabase', URL da base e chave pública anon/publishable compatível. Ajustar nomes das tabelas se a base usar outros. Nunca colocar service_role no navegador.
8. Servir public/ por HTTPS e testar o login de uma conta institucional autorizada. A interface usa a autenticação Supabase do SIGM, não o Keycloak do projeto React do Victor.

## Autorizações

As novas RPCs recusam acesso se sigm_operador_civil_autorizado() negar. Cadastro patrimonial também exige perfil adm. As leituras dependem de sessão autenticada e RLS/GRANT das tabelas de origem. Não remover RLS para solucionar uma falha de consulta. Os acessos das contas de Unidade, Galpão, Prestador e outros perfis precisam ser mapeados pelo programador antes de ampliar o público desta versão; não foram criados atalhos de acesso sem login.

## Gravações e concorrência

O número é emitido por sequência PostgreSQL e protegido por índice único. A chave requisicao_id fornecida pelo formulário é protegida por índice único e lock transacional; reenvio idêntico devolve o mesmo chamado, e dados diferentes com a mesma chave são recusados. Não se usa COUNT(*)+1 nem número do navegador na base real. Na alteração de status, o servidor trava o registro e compara atualizado_em para detectar edição concorrente. Auditoria e gravação ficam na mesma transação.

O início do SLA é gravado apenas na primeira liberação; a atualização reaproveita o prazo congelado. A rota não marca PAGO e não substitui o módulo financeiro. Chamados encerrados não são reabertos por este painel.

## Classificação e dados históricos

O agrupamento inteligente usa os nomes das categorias Civil e a identificação do equipamento: vazamento contínuo, hidráulica, cobertura/telhados, elétrica e climatização/ar-condicionado. Ele só ordena a exibição. Não muda categoria, prioridade ou prazo por inferência textual.

Os nomes dos campos patrimoniais foram mapeados a partir do backup: patrimonio_serie → tombamento, situacao_atual → status. Categoria e família ausentes aparecem como Não classificado; não são inventadas com base no nome. Na demonstração estão preenchidas. Revisar a taxonomia real antes de comparar contagens gerenciais.

## Volumes e validação antes do uso

O adaptador lê lotes de 200 registros e recusa apresentar contagem completa se uma consulta atingir 10.000 registros. Para volumes maiores, criar RPC/endpoint de agregação e paginação por unidade/família no servidor, com as mesmas políticas de acesso. Não aumentar o limite e chamar o resultado parcial de total. As amostras da triagem têm oito registros; os contadores usam o conjunto autorizado carregado.

Homologar com PostgreSQL real: duas criações simultâneas, reenvio idêntico, reenvio alterado, conta não autorizada, unidade/categoria inválida, prestador fora do contrato, SLA não revisado, ausência de GLPI, preservação de GLPI antigo, alteração concorrente, SLA sem reinício e cadastro de tombamento duplicado. Os testes de modelo e IndexedDB entregues não substituem esses testes de banco.
