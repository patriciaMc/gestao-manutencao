#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
echo 'Abra http://127.0.0.1:8082 no navegador. Para encerrar, Ctrl+C.'
python3 -m http.server 8082 --bind 127.0.0.1 --directory public
