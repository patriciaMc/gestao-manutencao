# Testes locais

Modelo (Node 20/22 ou superior):

```bash
node --test tests/model.test.mjs
```

Para o teste de interface, que grava somente dados fictícios:

```bash
python3 -m http.server 8083 --bind 127.0.0.1
```

Abra http://127.0.0.1:8083/tests/interface.html em um perfil de navegador destinado a testes. Aguarde a mensagem OK ao final da página. O teste recusa modo supabase. Cada execução deve usar um perfil novo ou os dados de demonstração desse perfil devem ser limpos antes, pois o teste grava chamados e verifica a contagem inicial da amostra.
