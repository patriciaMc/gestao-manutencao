import * as store from '../public/js/store.mjs';
const esperar=ms=>new Promise(r=>setTimeout(r,ms));
const check=(v,t)=>{if(!v)throw Error(t);};
async function aguardar(fn){for(let i=0;i<70;i++){if(fn())return;await esperar(100);}throw Error('Interface não respondeu a tempo.');}
try{
 check(store.modo==='demo','Os testes de gravação só podem rodar em modo demo.');
 await aguardar(()=>document.querySelector('[href="#civil/novo"].btn'));
 check(document.body.textContent.includes('SLA vencido'),'Painel sem controle de SLA');
 location.hash='civil/novo';await aguardar(()=>document.querySelector('#n-unidade'));
 const $=s=>document.querySelector(s);
 $('#n-unidade').value='1';$('#n-unidade').dispatchEvent(new Event('change'));
 $('#n-categoria').value='1';$('#n-categoria').dispatchEvent(new Event('change'));
 check($('#contexto').textContent.includes('Já há 1 chamado(s)'),'Não mostrou chamado existente da mesma categoria');
 check(!document.querySelector('[name="id_glpi"]'),'Triagem continua exigindo GLPI');
 $('#n-prestador').value='p1';$('#n-descricao').value='Demanda de teste de integração no navegador';
 $('#triagem').requestSubmit();await aguardar(()=>location.hash==='#civil');
 check(document.body.textContent.includes('CIV-'),'Não gerou número próprio');
 let dados=await store.carregar();const n=dados.chamados.find(r=>r.descricao==='Demanda de teste de integração no navegador');check(n&&!n.inicio_sla,'Avaliação iniciou SLA indevidamente');
 await store.atualizarChamado(n,'LIBERADO PARA ATENDIMENTO (PLANEJADO)','Liberação de teste');dados=await store.carregar();const liberado=dados.chamados.find(r=>r.id===n.id);check(liberado.inicio_sla&&liberado.vence_em,'Liberação não iniciou SLA');
 await store.atualizarChamado(liberado,'EM ROTA','Visita de teste agendada');dados=await store.carregar();const rota=dados.chamados.find(r=>r.id===n.id);check(rota.inicio_sla===liberado.inicio_sla&&rota.vence_em===liberado.vence_em,'Atualização reiniciou SLA');
 const p={familia:'EQUIPAMENTOS',unidade_id:'1',categoria_id:'6',equipamento:'Ar-condicionado Split',descricao:'Teste concorrente de numeração própria',prioridade:'Média',status_sigm:'SOLICITO AVALIAÇÃO TÉCNICA',requisicao_id:crypto.randomUUID()};
 const [a,b]=await Promise.all([store.salvarTriagem(p),store.salvarTriagem(p)]);check(a.id===b.id,'Reenvio duplicou chamado');
 const [c,d]=await Promise.all([store.salvarTriagem({...p,requisicao_id:crypto.randomUUID()}),store.salvarTriagem({...p,requisicao_id:crypto.randomUUID()})]);check(c.numero_chamado!==d.numero_chamado,'Concorrência duplicou número');
 location.hash='equipamentos';await aguardar(()=>document.querySelector('h1')?.textContent==='Triagem Equipamentos');
 check(document.body.textContent.includes('Ar-condicionado'),'Não mostrou ar-condicionado');
 document.body.dataset.teste='OK';const out=document.createElement('pre');out.id='resultado-teste';out.textContent='OK: painel, numeração própria, amostragem por unidade e categoria, cadastro sem GLPI, SLA só após liberação, prazo preservado, idempotência e numeração concorrente.';document.body.append(out);
}catch(e){document.body.dataset.teste='FALHA';const out=document.createElement('pre');out.id='resultado-teste';out.textContent='FALHA: '+e.message;document.body.append(out);}
