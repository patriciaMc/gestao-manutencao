// Copie para config.js somente para conectar sua própria base de teste Supabase.
// Não use service_role no navegador. O acesso depende do login e das políticas RLS.
window.SIGM_CONFIG = {
  modo: 'demo', // 'supabase' somente após aplicar/revisar a migração SQL.
  supabaseUrl: '',
  supabaseAnonKey: '',
  tabelas: { unidades:'sigm_unidades_cadastro',categorias:'sigm_categorias_civil',prestadores:'prestadores',patrimonios:'sigm_patrimonios_cadastro' }
};
