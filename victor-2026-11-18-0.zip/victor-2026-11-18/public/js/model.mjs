export const STATUS = ['SOLICITO AVALIAÇÃO TÉCNICA','LIBERADO PARA ATENDIMENTO (PLANEJADO)','AGENDADO VISITA','AGUARDANDO RESPOSTA VIA SISTEMA','EM ROTA','EM EXECUÇÃO','EXECUTADO','PAGO','CANCELADO'];
export const FECHADOS = ['EXECUTADO','PAGO','CANCELADO','CONCLUÍDO','ENCERRADO','UNIFICADO','DUPLICADO'];
export const norm = v => String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ar[ -]?condicionados?\b/g,'ar condicionado').trim();
export const esc = v => String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const moeda = n => Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
export function destaque(r){
 const c=norm(r.categoria_nome),d=norm(r.descricao),e=norm(r.equipamento),familia=r.familia;
 if(familia==='CIVIL'&&/vazamento (?:continuo|constante|sem parar)|vaza (?:continuamente|sem parar)/.test(c+' '+d))return {ordem:0,nome:'Vazamento contínuo'};
 if(familia==='CIVIL'&&/hidraul|hidrossanita/.test(c))return {ordem:1,nome:'Hidráulica'};
 if(familia==='CIVIL'&&/telhad|cobertura/.test(c))return {ordem:2,nome:'Telhado / cobertura'};
 if(familia==='CIVIL'&&/eletric/.test(c))return {ordem:3,nome:'Elétrica'};
 if(familia==='EQUIPAMENTOS'&&/ar[ -]?condicionado|climatiza/.test(e+' '+c))return {ordem:4,nome:'Ar-condicionado'};
 return {ordem:9,nome:''};
}
export function sla(r,agora=Date.now()){
 if(FECHADOS.includes(r.status_sigm))return {tipo:'encerrado',texto:'Encerrado',vencido:false};
 if(!r.inicio_sla)return {tipo:'aguardando',texto:'Aguardando liberação',vencido:false};
 if(r.prioridade==='Baixa')return {tipo:'planejado',texto:'Planejado',vencido:false};
 if(!r.vence_em)return {tipo:'erro',texto:'Prazo não configurado',vencido:false};
 const prazo=Date.parse(r.vence_em);if(!Number.isFinite(prazo))return {tipo:'erro',texto:'Revisar prazo',vencido:false};
 const minutos=Math.ceil((prazo-agora)/60000),abs=Math.abs(minutos),tempo=abs>=60?`${Math.floor(abs/60)}h ${abs%60}min`:`${abs}min`;
 return {tipo:minutos<0?'atrasado':'no-prazo',texto:minutos<0?`Vencido há ${tempo}`:`Restam ${tempo}`,vencido:minutos<0};
}
export function ordenarChamados(a,agora=Date.now()){
 return [...a].sort((x,y)=>Number(FECHADOS.includes(x.status_sigm))-Number(FECHADOS.includes(y.status_sigm))||destaque(x).ordem-destaque(y).ordem||Number(sla(y,agora).vencido)-Number(sla(x,agora).vencido)||String(x.criado_em).localeCompare(String(y.criado_em))||String(x.id).localeCompare(String(y.id)));
}
export function filtrarChamados(a,f={}){const q=norm(f.busca);return a.filter(r=>(!f.familia||r.familia===f.familia)&&(!f.unidade||String(r.unidade_id)===f.unidade)&&(!f.categoria||String(r.categoria_id)===f.categoria)&&(!f.status||r.status_sigm===f.status)&&(!q||norm([r.numero_chamado,r.id_glpi,r.descricao,r.unidade_nome,r.categoria_nome,r.equipamento].join(' ')).includes(q)));}
export function agrupar(a,chave,nome){const m=new Map();for(const r of a){const id=String(r[chave]??'sem'),n=String(r[nome]||'Não informado');m.set(id,{id,nome:n,total:(m.get(id)?.total||0)+1});}return [...m.values()].sort((a,b)=>b.total-a.total||a.nome.localeCompare(b.nome,'pt-BR'));}
export function proximoSla(r,status,prioridade,politica,agora=new Date()){
 const liberado=['LIBERADO PARA ATENDIMENTO (PLANEJADO)','EM ROTA','EM EXECUÇÃO'].includes(status);
 const inicio=r.inicio_sla||(liberado?agora.toISOString():null);
 const horas=r.inicio_sla?r.sla_horas:prioridade==='Baixa'?null:prioridade==='Muito Alta'?Number(politica.muito_alta):Number(politica.media);
 if(horas!==null&&(!Number.isFinite(horas)||horas<=0))throw Error('Configure um SLA válido antes de liberar.');
 return {inicio_sla:inicio,sla_horas:horas,vence_em:inicio&&horas?new Date(Date.parse(inicio)+horas*3600000).toISOString():null};
}
export function validarTriagem(p){
 for(const campo of ['familia','unidade_id','categoria_id','descricao','prioridade','status_sigm'])if(!String(p[campo]||'').trim())throw Error('Preencha '+campo.replaceAll('_',' ')+'.');
 if(!['CIVIL','EQUIPAMENTOS'].includes(p.familia))throw Error('Família inválida.');
 if(!['Média','Muito Alta','Baixa'].includes(p.prioridade))throw Error('Prioridade inválida.');
 if(!STATUS.slice(0,2).includes(p.status_sigm))throw Error('Status inicial inválido.');
 if(p.descricao.trim().length<5)throw Error('Descreva a demanda com pelo menos cinco caracteres.');
 if(p.familia==='EQUIPAMENTOS'&&!String(p.equipamento||'').trim())throw Error('Informe o equipamento.');
 if(p.familia==='CIVIL'&&!p.prestador_id)throw Error('Selecione o prestador.');
}
